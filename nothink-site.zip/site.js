/* Nothink shared script: home link, grid squares, page curtain, menu, appear animations, loader, closing film.
   Every block checks that its elements exist, so the same file works on every page. */
(() => {
  const root = document.documentElement;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');

  /* Links back to the home page: the published site opens at "./", the local preview at preview.html */
  const isLocal = /^(localhost|127\.0\.0\.1|\[::1\]|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(location.hostname) || location.hostname.endsWith('.local');
  const home = isLocal ? 'preview.html' : './';
  document.querySelectorAll('a[data-home]').forEach(a => a.setAttribute('href', home + a.dataset.home));

  /* Square markers where the grid lines meet each section's top and middle */
  document.querySelectorAll('.sec').forEach(s => {
    const rows = s.classList.contains('rows2') ? ['var(--pt)', 'calc(var(--pt) + (100% - var(--pt)) / 2)'] : ['var(--pt)'];
    rows.forEach((top, i) => {
      const m = document.createElement('div');
      m.className = i ? 'marks mid' : 'marks';
      m.style.top = top;
      m.setAttribute('aria-hidden', 'true');
      m.innerHTML = '<i></i><i></i><i></i><i></i><i></i>';
      s.append(m);
    });
  });

  /* Page curtain: wipes up before moving to another page; the next page's loader wipes it away */
  const curtain = document.createElement('div');
  curtain.className = 'curtain';
  curtain.setAttribute('aria-hidden', 'true');
  document.body.append(curtain);
  addEventListener('pageshow', e => { if (e.persisted) curtain.classList.remove('show'); });
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target === '_blank') return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname === location.pathname) return;
    e.preventDefault();
    if (reducedMotion.matches) { location.href = url.href; return; }
    curtain.classList.add('show');
    setTimeout(() => { location.href = url.href; }, 620);
  });

  /* Menu: the header bar drops down into a panel */
  const bar = document.getElementById('bar');
  const menuBtn = document.getElementById('menu-btn');
  const servicesBtn = document.getElementById('services-btn');
  const menu = document.getElementById('menu');
  if (bar && menuBtn && menu) {
    const isOpen = () => bar.classList.contains('open');
    const setMenu = open => {
      bar.classList.toggle('open', open);
      menu.inert = !open;
      menu.setAttribute('aria-hidden', String(!open));
      [menuBtn, servicesBtn].forEach(b => b && b.setAttribute('aria-expanded', String(open)));
      menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    };
    menuBtn.addEventListener('click', () => setMenu(!isOpen()));
    if (servicesBtn) servicesBtn.addEventListener('click', () => setMenu(!isOpen()));
    menu.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
    /* Mark the page you are on (works with or without ".html" in the address) */
    const clean = path => path.replace(/\.html$/, '').replace(/\/(index|preview)$/, '/');
    menu.querySelectorAll('a[href]').forEach(a => {
      const url = new URL(a.href, location.href);
      if (!url.hash && url.origin === location.origin && clean(url.pathname) === clean(location.pathname)) a.setAttribute('aria-current', 'page');
    });
    /* Square markers where the menu's lines meet, like the page grid.
       Each horizontal line gets a square at both ends and wherever a divider above or below touches it. */
    const thirds = ['33.3333%', '66.6667%'];
    const addJoints = (el, stops) => {
      if (!el) return;
      const row = document.createElement('div');
      row.className = 'menu-joints';
      row.setAttribute('aria-hidden', 'true');
      [['0%', 'j-end'], ...stops, ['100%', 'j-end']].forEach(([x, kind]) => {
        const i = document.createElement('i');
        i.className = kind;
        i.style.left = kind === 'j-end' ? (x === '0%' ? '.5px' : 'calc(100% - .5px)') : `calc(${x} + .5px)`;
        row.append(i);
      });
      el.append(row);
    };
    menu.querySelectorAll('.menu-cards, .menu-mail').forEach(el => addJoints(el, thirds.map(x => [x, 'j-mid'])));
    /* Start loading the menu images as soon as a visitor reaches for the menu, so they are ready when it opens */
    const warm = () => menu.querySelectorAll('img[loading="lazy"]').forEach(img => { img.loading = 'eager'; });
    [menuBtn, servicesBtn].forEach(b => b && ['pointerenter', 'focus', 'touchstart'].forEach(t => b.addEventListener(t, warm, { once: true, passive: true })));
    document.addEventListener('click', e => { if (isOpen() && !bar.contains(e.target)) setMenu(false); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && isOpen()) { setMenu(false); menuBtn.focus(); } });
  }

  /* Appear animations: tag what should animate, then reveal each item once as it scrolls into view.
     Items entering together are staggered in page order. Inner pages also tag items directly in their HTML. */
  const tagReveal = (selector, type) => document.querySelectorAll(selector).forEach(el => { el.dataset.reveal = type; });
  tagReveal('.sec', 'draw');
  tagReveal('main .media', 'wipe');
  tagReveal('.marks', 'pop');
  tagReveal('.s01 .cell, .project-process > h2, .project-step, .about-copy, .skills-copy, .testimonial-placeholder, .closing-message > *, .closing-footer > div', 'rise');
  let revealsStarted = false;
  function startReveals() {
    if (revealsStarted) return;
    revealsStarted = true;
    const items = [...document.querySelectorAll('[data-reveal]')];
    if (reducedMotion.matches || !('IntersectionObserver' in window)) { items.forEach(el => el.classList.add('is-in')); return; }
    const io = new IntersectionObserver(entries => {
      const hits = entries.filter(e => e.isIntersecting).map(e => e.target);
      hits.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);
      hits.forEach((el, i) => {
        el.style.setProperty('--d', Math.min(i, 8) * 90 + 'ms');
        el.classList.add('is-in');
        io.unobserve(el);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -5% 0px' });
    items.forEach(el => io.observe(el));
  }

  /* Loader: full length on the first visit, short on inner pages and return visits */
  const loader = document.getElementById('loader');
  let seen = false;
  try { seen = sessionStorage.getItem('nt-seen') === '1'; sessionStorage.setItem('nt-seen', '1'); } catch (_) { /* storage blocked: use full loader */ }
  const begin = () => {
    if (root.classList.contains('ready')) return;
    root.classList.add('ready');
    startReveals();
  };
  const hideLoader = () => { if (loader) loader.classList.add('done'); begin(); };
  if (loader) {
    loader.addEventListener('click', hideLoader);
    setTimeout(hideLoader, loader.dataset.quick === 'true' || seen ? 500 : 1400);
  } else {
    begin();
  }

  /* Closing film (home page): expands from the middle columns to the full frame while scrolling */
  const wrap = document.getElementById('closing-scroll');
  const grow = document.getElementById('closing-film');
  if (wrap && grow) {
    let frame = 0;
    const update = () => {
      frame = 0;
      const span = Math.max(1, wrap.offsetHeight - innerHeight);
      const progress = Math.min(1, Math.max(0, -wrap.getBoundingClientRect().top / span));
      // Start exactly inside the grid box (phones: full width of the top row; desktop: columns 2-3 of the top row), then fill the screen
      const start = innerWidth <= 820 ? 100 : 50;
      grow.style.width = (reducedMotion.matches ? 100 : start + (100 - start) * progress) + '%';
      grow.style.height = (reducedMotion.matches ? 100 : 50 + 50 * progress) + '%';
    };
    const queue = () => { if (!frame) frame = requestAnimationFrame(update); };
    addEventListener('scroll', queue, { passive: true });
    addEventListener('resize', queue);
    reducedMotion.addEventListener('change', queue);
    update();
  }
})();

/* Anchor gallery squares, the MSL row and the home hero seam to measured boundaries. */
(() => {
 const gallery=document.querySelector('.photoshoot-grid');
 const msl=document.getElementById('case-msl');
 const hero=document.getElementById('s01');
 let scheduled=false;
 const update=()=>{
  scheduled=false;
  if(gallery){
   gallery.querySelectorAll('.gallery-joints').forEach(x=>x.remove());
   const rect=gallery.getBoundingClientRect();
   const rows=[...new Set([...gallery.querySelectorAll('.photo-card')].map(x=>Math.round((x.getBoundingClientRect().top-rect.top)*100)/100))];
   for(const y of rows){
    const line=document.createElement('div');line.className='gallery-joints';line.setAttribute('aria-hidden','true');line.style.top=y+'px';
    for(const x of (innerWidth<=820?[0,100]:[0,25,50,75,100])){const dot=document.createElement('i');dot.style.left=x+'%';line.append(dot);}
    gallery.append(line);
   }
  }
  if(msl && innerWidth>820){const row=msl.querySelector('.c-row2');if(row)msl.style.setProperty('--msl-row',(row.getBoundingClientRect().top-msl.getBoundingClientRect().top)+'px');}
  if(hero && innerWidth>820){const row=hero.querySelector('.h-v1');if(row)hero.style.setProperty('--s01-row',(row.offsetTop+row.offsetHeight)+'px');}
 };
 const queue=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update);}};
 const observer=new ResizeObserver(queue);
 if(gallery)observer.observe(gallery);
 if(msl)observer.observe(msl);
 if(hero){observer.observe(hero);const cell=hero.querySelector('.h-t2');if(cell)observer.observe(cell);const top=hero.querySelector('.h-v1');if(top)observer.observe(top);}
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(queue);
 addEventListener('resize',queue);addEventListener('load',queue);queue();
})();

/* Music button: off until the visitor turns it on. Once on, it keeps playing from page to page until it is stopped:
   it fades out under the page curtain and fades back in on the next page from the same spot.
   A new visit waits for a tap before playing, even if music was on last time.
   The button stays hidden until the track file loads, so a missing file never shows a broken button. */
(() => {
  const services = document.getElementById('services-btn');
  if (!services) return;
  const btn = document.createElement('button');
  btn.className = 'music-btn';
  btn.type = 'button';
  btn.hidden = true;
  btn.innerHTML = '<span class="music-bars" aria-hidden="true"><i></i><i></i><i></i><i></i></span>';
  const end = document.createElement('div');
  end.className = 'bar-end';
  services.replaceWith(end);
  end.append(btn, services);

  const VOLUME = 0.55;
  const store = (area, key, value) => { try { return value === undefined ? area.getItem(key) : area.setItem(key, value); } catch (_) { return null; } };
  /* "On in this visit": set only when the visitor turns the music on or off */
  const onThisVisit = () => store(sessionStorage, 'nt-music-live') === '1';
  const remember = on => { store(localStorage, 'nt-music', on ? 'on' : 'off'); store(sessionStorage, 'nt-music-live', on ? '1' : '0'); };
  const savedTime = () => parseFloat(store(sessionStorage, 'nt-music-time'));
  const audio = new Audio('assets/music/nothink-theme.m4a');
  audio.loop = true;
  audio.preload = 'metadata';
  audio.volume = VOLUME;
  let wanted = false;
  let request = 0;
  let fadeFrame = 0;
  const fadeTo = (target, ms) => {
    cancelAnimationFrame(fadeFrame);
    const from = audio.volume, t0 = performance.now();
    const step = now => {
      const k = Math.min(1, (now - t0) / ms);
      try { audio.volume = from + (target - from) * k; } catch (_) { return; }
      if (k < 1) fadeFrame = requestAnimationFrame(step);
    };
    fadeFrame = requestAnimationFrame(step);
  };
  const show = playing => {
    btn.classList.toggle('is-playing', playing);
    btn.setAttribute('aria-pressed', String(playing));
    btn.setAttribute('aria-label', playing ? 'Pause music' : 'Play music');
  };
  const busy = value => btn.setAttribute('aria-busy', String(value));
  /* Resolves true once the track is really playing with sound. The audio is never muted, so a browser that
     has not unlocked sound refuses instead of playing silently and looking as if it worked. */
  const play = (fadeIn = false) => {
    wanted = true;
    const current = ++request;
    busy(true);
    cancelAnimationFrame(fadeFrame);
    audio.volume = fadeIn ? 0 : VOLUME;
    if (audio.error) audio.load();
    return audio.play().then(() => {
      if (current !== request) return false;
      busy(false);
      show(true);
      if (fadeIn) fadeTo(VOLUME, 900);
      return true;
    }).catch(() => {
      if (current !== request) return false;
      wanted = false;
      busy(false);
      show(false);
      audio.volume = VOLUME;
      return false;
    });
  };
  const pause = () => {
    wanted = false;
    ++request;
    cancelAnimationFrame(fadeFrame);
    audio.pause();
    audio.volume = VOLUME;
    busy(false);
    show(false);
  };
  /* Some browsers (Safari, some in-app browsers) need a fresh tap on every page before sound can start */
  const playOnNextTap = () => {
    const resume = e => {
      if (e.type === 'keydown' && !['Enter', ' '].includes(e.key)) return;
      ['click', 'keydown', 'touchend'].forEach(t => document.removeEventListener(t, resume));
      if (!btn.contains(e.target)) play().then(ok => { if (ok) store(sessionStorage, 'nt-music-live', '1'); });
    };
    ['click', 'keydown', 'touchend'].forEach(t => document.addEventListener(t, resume));
  };
  show(false);

  audio.addEventListener('loadedmetadata', () => {
    btn.hidden = false;
    const t = savedTime();
    if (t > 0 && t < audio.duration) audio.currentTime = t;
    if (onThisVisit()) {
      // Music was playing on the previous page: carry straight on
      play(true).then(ok => { if (!ok) playOnNextTap(); });
    } else if (store(localStorage, 'nt-music') === 'on') {
      // A returning visitor who left the music on: start on their first tap, never by surprise
      playOnNextTap();
    }
  }, { once: true });

  btn.addEventListener('click', () => {
    const on = !wanted;
    remember(on);
    if (on) play(); else pause();
  });
  audio.addEventListener('error', () => { wanted = false; ++request; busy(false); show(false); });

  /* Moving to another page of the site: fade out while the curtain wipes up */
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]');
    if (!wanted || !a || a.target === '_blank' || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const url = new URL(a.href, location.href);
    if (url.origin === location.origin && url.pathname !== location.pathname) fadeTo(0, 550);
  });
  addEventListener('pagehide', () => store(sessionStorage, 'nt-music-time', String(audio.currentTime)));
  /* Back/forward can restore a page from memory: match the music to what the visitor last chose, from the latest spot */
  addEventListener('pageshow', e => {
    if (!e.persisted) return;
    const t = savedTime();
    if (t > 0 && t < audio.duration) audio.currentTime = t;
    if (onThisVisit()) play(true).then(ok => { if (!ok) playOnNextTap(); });
    else pause();
  });
  document.addEventListener('visibilitychange', () => {
    if (!wanted) return;
    if (document.hidden) { ++request; audio.pause(); busy(false); show(false); }
    else if (onThisVisit()) play();
    else pause();
  });
})();

/* Preserve each clip's proportions on phones; reveal portrait frames on hover. */
(() => {
 document.querySelectorAll('.media > video').forEach(video => {
  const size=()=>{
   if(!video.videoWidth || !video.videoHeight)return;
   const box=video.parentElement;
   box.classList.add('video-proportions');
   box.classList.toggle('portrait-video',video.videoHeight>video.videoWidth);
   box.style.setProperty('--video-ratio',`${video.videoWidth} / ${video.videoHeight}`);
  };
  video.addEventListener('loadedmetadata',size);size();
 });
})();

/* Only load and play decorative video when it reaches the viewport. */
(() => {
 const videos=[...document.querySelectorAll('video[data-src]')];
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const visible=new Set();
 const sync=v=>{
  if(!visible.has(v)||document.hidden){v.pause();return;}
  if(!v.getAttribute('src')){v.src=v.dataset.src;v.load();}
  if(reduced.matches){v.pause();v.controls=true;return;}
  v.play().catch(error=>{if(error.name!=='AbortError')v.controls=true;});
 };
 if('IntersectionObserver' in window){
  const observer=new IntersectionObserver(entries=>entries.forEach(e=>{
   if(e.isIntersecting)visible.add(e.target);else visible.delete(e.target);
   sync(e.target);
  }),{threshold:.05});videos.forEach(v=>observer.observe(v));
 }else{videos.forEach(v=>{v.src=v.dataset.src;v.controls=true;});}
 document.addEventListener('visibilitychange',()=>videos.forEach(sync));
 reduced.addEventListener('change',()=>videos.forEach(sync));
 // Pause background music while a visitor watches a film with sound.
 document.querySelectorAll('video[controls]').forEach(v=>v.addEventListener('play',()=>{
  if(!v.muted){const b=document.querySelector('.music-btn.is-playing');if(b)b.click();}
 }));
})();

/* Expand portfolio artwork without leaving the project. */
(() => {
 const images=[...document.querySelectorAll('.case .media > img,.vantis-row .media > img,.mondo-gallery .media > img')];
 if(!images.length)return;
 const dialog=document.createElement('dialog'); dialog.className='portfolio-lightbox'; dialog.setAttribute('aria-label','Project image preview');
 const close=document.createElement('button');close.type='button';close.textContent='Close ×';
 const full=document.createElement('img'); dialog.append(close,full);document.body.append(dialog);
 close.addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 images.forEach(img=>{img.dataset.expand='';img.tabIndex=0;img.setAttribute('role','button');img.setAttribute('aria-label','Enlarge: '+img.alt);
 const open=()=>{full.src=img.currentSrc||img.src;full.alt=img.alt;dialog.showModal()};
 img.addEventListener('click',open);img.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open()}});
 });
})();

/* Door forms (free ad sample, monthly plan): save each lead to Nothink's own list, then open the door's thank-you page.
   LEAD_ENDPOINT is the Make webhook that writes each lead into the Notion list "Nothink Website Leads".
   While it is empty, or if sending fails, the visitor still reaches the thank-you page, and its WhatsApp button
   carries everything they typed, so no lead is lost. */
(() => {
  const LEAD_ENDPOINT = '';
  const WHATSAPP = '255742721993';
  const store = (key, value) => { try { return value === undefined ? sessionStorage.getItem(key) : sessionStorage.setItem(key, value); } catch (_) { return null; } };

  /* Where this visit came from (a utm tag, ?ref= or the referring site), kept so each door can be tracked */
  if (!store('nt-source')) {
    const q = new URLSearchParams(location.search);
    const tag = ['utm_source', 'utm_medium', 'utm_campaign'].map(k => q.get(k)).filter(Boolean).join(' / ') || q.get('ref') || '';
    let site = '';
    try { if (document.referrer) { const host = new URL(document.referrer).host; if (host !== location.host) site = host; } } catch (_) { /* no referrer */ }
    store('nt-source', tag || site || 'direct');
  }

  document.querySelectorAll('form.door-form').forEach(form => {
    const button = form.querySelector('button[type="submit"]');
    form.addEventListener('submit', async e => {
      e.preventDefault();
      if (form.elements.company && form.elements.company.value) return; // a hidden field only bots fill in
      if (!form.reportValidity()) return;
      const data = Object.fromEntries(new FormData(form));
      delete data.company;
      Object.assign(data, { door: form.dataset.door, page: location.href.split('#')[0], source: store('nt-source') || 'direct', sent: new Date().toISOString() });
      store('nt-lead', JSON.stringify({ name: data.name || '', brand: data.brand || '', email: data.email || '', sells: data.sells || '', notes: data.notes || '' }));
      if (button) button.setAttribute('aria-busy', 'true');
      if (LEAD_ENDPOINT) {
        const stop = new AbortController();
        const timer = setTimeout(() => stop.abort(), 6000);
        try { await fetch(LEAD_ENDPOINT, { method: 'POST', mode: 'no-cors', body: new URLSearchParams(data), signal: stop.signal }); } catch (_) { /* the thank-you page still offers WhatsApp */ }
        clearTimeout(timer);
      }
      location.href = form.dataset.thanks;
    });
  });

  /* Thank-you pages: greet the visitor by name and put their details into the WhatsApp message */
  const page = document.querySelector('[data-wa-template]');
  if (!page) return;
  let lead = {};
  try { lead = JSON.parse(store('nt-lead') || '{}') || {}; } catch (_) { lead = {}; }
  const first = (lead.name || '').trim().split(/\s+/)[0];
  if (first) document.querySelectorAll('[data-lead-name]').forEach(el => { el.textContent = first; el.closest('[data-lead-wrap]')?.removeAttribute('hidden'); });
  /* {details} in a template marks where their answers go; without it they go at the end */
  const details = [lead.sells && `We sell: ${lead.sells}`, lead.notes && `Ads now: ${lead.notes}`, lead.email && `Email: ${lead.email}`].filter(Boolean).join('\n');
  let message = page.dataset.waFallback;
  if (lead.name) {
    message = page.dataset.waTemplate.replace('{name}', lead.name.trim()).replace('{brand}', (lead.brand || 'my brand').trim());
    message = message.includes('{details}') ? message.replace('{details}', details ? `\n${details}\n` : ' ') : [message, details].filter(Boolean).join('\n');
  }
  document.querySelectorAll('a[data-wa]').forEach(a => { a.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`; });
})();
